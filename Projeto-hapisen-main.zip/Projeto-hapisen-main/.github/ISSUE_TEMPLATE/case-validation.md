---
name: Case validation
about: Registrar falha ou validação de um cenário experimental
title: "[CASE] "
labels: experiment
---

Case: A0X
Data:
Commit:
Ambiente:
Passos executados:
Resultado esperado:
Resultado observado:
Logs/evidências:
